</div>
<div class="p-5 text-center ">
	<h6 <span style="color:#00D5FF;"><?php $this->options->footersay() ?></span></h6>
	 <span id="typed">Loading</span>
 <h6 class="lover-card-title">愿我如星君如月,夜夜流光相皎洁</h6> 
</div>
<link rel="stylesheet" href="https://cdn.gmit.vip/FontAwesome/css/font-awesome.min.css" type="text/css" media="all" />
<script src="https://cdn.gmit.vip/blog/js/typed.min.js" type="text/javascript" charset="utf-8"></script>
<!--鼠标点击特效-->
<script type="text/javascript">
jQuery(function () {
        $("html").click(function(e) {
            var a_idx = Math.floor((Math.random() * 30));
            var a = new Array(
                "希望全世界停电 我可以偷偷跑去亲你", "我会爱你很久很久","我在贩卖日落 你像神明一样将阳光撒向我","陪伴本身就是这个世界上最了不起的安慰方式", "嘿，我是一朵云ლ(⁰⊖⁰ლ)", "❤"
                   ,"陪你把岁月熬成清酒 陪你把孤夜熬成温柔","❤","月光下邂逅的是爱情和你","祝眉目舒展 顺问冬按","只想拥你入怀","这个世界乱糟糟的 而你干干净净","日月星辰之外 你是第四种难得","我会在每个有意义的时刻 远隔山海与你共存","山脚下遇见的你 我们山顶见","想试试在你迎面跑来一把抱住你的感觉","在生命里的旅程里 遇见你真好","如果不曾遇见 岂知生命如何","❤"
                   ,"想和你一起走过下雪后的天","在我贫瘠的土地上你是最后的玫瑰","今晚月色很美呢","r=a(1-sinθ)","天青色等烟雨 而我在等你","你是我这一生等了半世未拆的礼物","你养我 我养你 两人爱情甜蜜蜜","❤","你不用多好，我喜欢就好","愿有岁月可回首 且以深情共白头"
                 );
            var color1 = Math.floor((Math.random() * 255))
            var color2 = Math.floor((Math.random() * 255));
            var color3 = Math.floor((Math.random() * 255));

            var $i = $("<span />").text(a[a_idx]);
            // a_idx = (a_idx + 1) % a.length;
            var x = e.pageX,
                y = e.pageY;
            $i.css({
                "z-index": 9999999999999 ,
                "top": y - 20,
                "left": x,
                "position": "absolute",
                "font-family":"mmm",
                "fontSize":Math.floor((Math.random() * 5)+10),
                "font-weight": "bold",
                "color": "rgb("+color1+","+color2+","+color3+")",
                "-webkit-user-select":"none",
                "-moz-user-select":"none",
                "-ms-user-select":"none",
                "user-select":"none",
            });
            $("body").append($i);
            $i.animate({
                    "top": y - 200,
                    "opacity": 0
                },
                3000,
                function() {
                    $i.remove();
                });
        });
    });
</script>
<!--动态-->
<script type="text/javascript">
/*  动态网页标题*/
     var OriginTitile = document.title,
      titleTime;
     document.addEventListener("visibilitychange",
     function() {
      if (document.hidden) {
        document.title = "你有新的未读消息！";
        clearTimeout(titleTime)
    } else {
        document.title = "༼ つ ◕_◕ ༽つ你可算回来了！" ;
        titleTime = setTimeout(function() {
            document.title = OriginTitile
        },
        2000)
    }
    });
//控制台添加说明 
if  (window.console) {
     var  cons = console;
     if  (cons) {
       console.log("\n %c 君临 - wxnljun","color:#fff; background: linear-gradient(to right , #7A88FF, #d27aff); padding:5px; border-radius: 10px;");
       cons.log( "%c\君临" ,  "font-size:70px;" );
       console.log('%c网站：君临(wxnljun/)\n说明：如果你通过控制台的方式获取CSS样式或者其他东东，相信你可能也看到本说明。如果你想一声不吭的拿走，请自己把所有涉及到的链接图片保存到本地，谢谢！\n作者：1825703954\n更多精彩文章教程，请收藏本站。','color:red;font-size:20px;');
       console.log('%c ','background-image:url("https://q4.qlogo.cn/headimg_dl?dst_uin=277710066&spec=100");background-size:100% 100%;padding:30px 150px;');
     }
};</script>

<script>
function auto_comment_image( $comment ) {
	global $allowedtags;
	$allowedtags['img'] = array('src' => array (), 'alt' => array ());
	return $comment;
}
add_filter('preprocess_comment', 'auto_comment_image');
</script>

<!--雪花特效-->
<!--<script src="https://cdn.jsdelivr.net/gh/pyrrole-ach/IMG/snowy.js"></script>-->
<script src="https://lf6-cdn-tos.bytecdntp.com/cdn/expire-1-M/jquery.pjax/2.0.1/jquery.pjax.min.js"></script>
<script src="https://lf26-cdn-tos.bytecdntp.com/cdn/expire-1-M/nprogress/0.2.0/nprogress.min.js"></script>
<script src="https://cdn.qqsuu.cn/api/js/hua.js"></script>
<script>
	window.showSiteRuntime = function() {
		site_runtime = $("#site_runtime");
		if (!site_runtime) {
			return;
		}
		window.setTimeout("showSiteRuntime()", 1000);
		start = new Date("<?php $this->options->lovetime(); ?>");
		now = new Date();
		T = (now.getTime() - start.getTime());
		i = 24 * 60 * 60 * 1000;
		d = T / i;
		D = Math.floor(d);
		h = (d - D) * 24;
		H = Math.floor(h);
		m = (h - H) * 60;
		M = Math.floor(m);
		s = (m - M) * 60
		S = Math.floor(s);
		site_runtime.html("第 <span class=\"bigfontNum\">" + D + "</span> 天 <span class=\"bigfontNum\">" + H + "</span> 小时 <span class=\"bigfontNum\">" + M + "</span> 分钟 <span class=\"bigfontNum\">" + S + "</span> 秒");
	};
	showSiteRuntime();
	$(document).pjax('a', '#Pjax', {
		fragment: '#Pjax',
		timeout: 6000
	});
	$(document).on('pjax:send', function() {
		NProgress.start();
	});
	$(document).on('pjax:complete', function() {
		<?php if ($this->options->pjaxContent) : $this->options->pjax回调(); ?><?php endif; ?>
		NProgress.done();
	});
</script>
<script>
	window.showMeetRuntime = function() {
		meet_runtime = $("#meet_runtime");
		if (!meet_runtime) {
			return;
		}
		window.setTimeout("showMeetRuntime()", 1000);
		start = new Date("<?php $this->options->meetingtime(); ?>");
		now = new Date();
		T = (now.getTime() - start.getTime());
		i = 24 * 60 * 60 * 1000;
		d = T / i;
		D = Math.floor(d);
		h = (d - D) * 24;
		H = Math.floor(h);
		m = (h - H) * 60;
		M = Math.floor(m);
		s = (m - M) * 60
		S = Math.floor(s);
		meet_runtime.html("第 <span class=\"bigfontNum\">" + D + "</span> 天 <span class=\"bigfontNum\">" + H + "</span> 小时 <span class=\"bigfontNum\">" + M + "</span> 分钟 <span class=\"bigfontNum\">" + S + "</span> 秒");
	};
	showMeetRuntime();
</script>
<script>
	window.showEndRuntime = function() {
		<?php $this->options->anniversary() ?> = $("#<?php $this->options->anniversary() ?>");
		if (!<?php $this->options->anniversary() ?>) {
			return;
		}
		window.setTimeout("showEndRuntime()", 1000);
		end = new Date("<?php $this->options->endingtime(); ?>");
		now = new Date();
		T = (end.getTime() - now.getTime());
		i = 24 * 60 * 60 * 1000;
		d = T / i;
		D = Math.floor(d);
		h = (d - D) * 24;
		H = Math.floor(h);
		m = (h - H) * 60;
		M = Math.floor(m);
		s = (m - M) * 60
		S = Math.floor(s);
		<?php $this->options->anniversary() ?>.html("<span class=\"bigfontNum\">" + D + "</span> 天 <span class=\"bigfontNum\">" + H + "</span> 小时 <span class=\"bigfontNum\">" + M + "</span> 分钟 <span class=\"bigfontNum\">" + S + "</span> 秒");
	};
	showEndRuntime();
</script>
<script src="<?php $this->options->themeUrl('/base/main.js'); ?>"></script>
<?php $this->footer(); ?>
<?php if ($this->options->底部自定义) : $this->options->底部自定义(); ?><?php endif; ?>
 <style type="text/css">
  .snow-container{position:fixed;top:0;left:0;width:100%;height:100%;pointer-events:none;z-index:100001;}
  </style>
  <div class="snow-container"></div>
<!--下雪特效，雪花会被鼠标吹走-->
<canvas id="Snow"></canvas>
<script>
    if(true){
        (function() {
            var requestAnimationFrame = window.requestAnimationFrame || window.mozRequestAnimationFrame || window.webkitRequestAnimationFrame || window.msRequestAnimationFrame ||
            function(callback) {
                window.setTimeout(callback, 1000 / 60);
            };
            window.requestAnimationFrame = requestAnimationFrame;
        })();
        
        (function() {
            var flakes = [],
                canvas = document.getElementById("Snow"),
                ctx = canvas.getContext("2d"),
                flakeCount = 200,
                mX = -100,
                mY = -100;
            
            canvas.width = window.innerWidth;
            canvas.height = window.innerHeight;
            
            function snow() {
                ctx.clearRect(0, 0, canvas.width, canvas.height);
            
                for (var i = 0; i < flakeCount; i++) {
                    var flake = flakes[i],
                        x = mX,
                        y = mY,
                        minDist = 150,
                        x2 = flake.x,
                        y2 = flake.y;
            
                    var dist = Math.sqrt((x2 - x) * (x2 - x) + (y2 - y) * (y2 - y)),
                        dx = x2 - x,
                        dy = y2 - y;
            
                    if (dist < minDist) {
                        var force = minDist / (dist * dist),
                            xcomp = (x - x2) / dist,
                            ycomp = (y - y2) / dist,
                            deltaV = force / 2;
            
                        flake.velX -= deltaV * xcomp;
                        flake.velY -= deltaV * ycomp;
            
                    } else {
                        flake.velX *= .98;
                        if (flake.velY <= flake.speed) {
                            flake.velY = flake.speed
                        }
                        flake.velX += Math.cos(flake.step += .05) * flake.stepSize;
                    }
            
                    ctx.fillStyle = "rgba(255,255,255," + flake.opacity + ")";
                    flake.y += flake.velY;
                    flake.x += flake.velX;
                        
                    if (flake.y >= canvas.height || flake.y <= 0) {
                        reset(flake);
                    }
            
                    if (flake.x >= canvas.width || flake.x <= 0) {
                        reset(flake);
                    }
            
                    ctx.beginPath();
                    ctx.arc(flake.x, flake.y, flake.size, 0, Math.PI * 2);
                    ctx.fill();
                }
                requestAnimationFrame(snow);
            };
            
            function reset(flake) {
                flake.x = Math.floor(Math.random() * canvas.width);
                flake.y = 0;
                flake.size = (Math.random() * 3) + 2;
                flake.speed = (Math.random() * 1) + 0.5;
                flake.velY = flake.speed;
                flake.velX = 0;
                flake.opacity = (Math.random() * 0.5) + 0.3;
            }
            
            function init() {
                for (var i = 0; i < flakeCount; i++) {
                    var x = Math.floor(Math.random() * canvas.width),
                        y = Math.floor(Math.random() * canvas.height),
                        size = (Math.random() * 3) + 2,
                        speed = (Math.random() * 1) + 0.5,
                        opacity = (Math.random() * 0.5) + 0.3;
            
                    flakes.push({
                        speed: speed,
                        velY: speed,
                        velX: 0,
                        x: x,
                        y: y,
                        size: size,
                        stepSize: (Math.random()) / 30 * 1,
                        step: 0,
                        angle: 180,
                        opacity: opacity
                    });
                }
            
                snow();
            };
            
            document.addEventListener("mousemove", function(e) {
                mX = e.clientX,
                mY = e.clientY
            });
            window.addEventListener("resize", function() {
                canvas.width = window.innerWidth;
                canvas.height = window.innerHeight;
            });
            init();
        })();
    }
</script>
<script src="https://love.zhimaozy.com/usr/themes/Brave/botui/botui.min.js"></script>
<style>
    #Snow{
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 99999;
        background: rgba(125,137,95,0.1);
        pointer-events: none;
    }
</style>
 <!--require APlayer音乐代码 -->
<link rel="stylesheet" href="/usr/themes/Brave/assets/css/APlayer.min.css">
<script src="/usr/themes/Brave/assets/js/APlayer.min.js"></script>
 <!--require MetingJS.false -->
<script src="/usr/themes/Brave/assets/js/Meting.min.js"></script>
<meting-js
	server="netease"/*插入网易云*/
	type="playlist"/*c插入歌单*/
	id="<?php $this->options->neteaseid() ?>"/*插入歌单id*/
	fixed="true"/*启用吸底模式*/
	autoplay="true"/*自动播放，仅适用于手机浏览器，经测试PC端和微信打开自动播放均会被禁止*/
	loop="all"/*循环播放*/
	>
</meting-js>
<!--评论框粒子特效-->
<script type="text/javascript" src="/usr/themes/Brave/assets/js/comment.js"></script>
<!--初音未来开始-->
<style>
.cywl {
    position: fixed!important;
    position: absolute;
    width: 70px;
    height: 75px;
    z-index: 9;
    right: 0;
    bottom: 0;
    top: expression(offsetParent.scrollTop+offsetParent.clientHeight-150);
    cursor: pointer;
}
</style>
<div id="audio" class="cywl">
<img src="https://external-30160.picsz.qpic.cn/39ff4096c204652d7c7b56418fb37631" width="65px" height="65px" id="d" onclick="c();">
</div>
<!--初音未来结束-->
<!-- 访问问候弹窗 --> 
<div id="fps" style="z-index:5;position:fixed;bottom:3px;left:3px;color:#2196F3;font-size:10px;-webkit-pointer-events: none; -moz-pointer-events: none; -ms-pointer-events: none; -o-pointer-events: none;"></div> <script type="text/javascript" src="http://xn--vbta.xn--6qq986b3xl/usr/themes/Brave/js/fetch.min.js"></script> <script src="https://cdn.gmit.vip/layer/3.1.1/layer.js" type="text/javascript" charset="utf-8"></script> <script> /*网站打开提醒代码开始*/ $(function(){ if(/*getCookie('msg') !=*/ 1){ var t = document.createElement("a"); t.href = document.referrer; var msgTitle = t.hostname; var name = t.hostname.split(".")[1]; if("" !== document.referrer){ switch (name) { case 'bing': msgTitle = '必应搜索'; break; case 'baidu': msgTitle = '百度搜索'; break; case 'so': msgTitle = '360搜索'; break; case 'google': msgTitle = '谷歌搜索'; break; case 'sm': msgTitle = '神马搜索'; break; case 'sogou': msgTitle = '搜狗搜索'; break; default: msgTitle = t.hostname; }; }; var time = (new Date).getHours(); var msg = ''; 23 < time || time <= 5 ? msg = "你是夜猫子呀？这么晚还不睡觉，明天起的来嘛？": 5< time && time <= 7 ? msg = "早上好！一日之计在于晨，美好的一天就要开始了！": 7< time && time <= 11 ? msg = "上午好！工作顺利嘛，不要久坐，多起来走动走动哦！": 11< time && time <= 14 ? msg = "中午了，工作了一个上午，现在是午餐时间！": 14< time && time <= 17 ? msg = "午后很容易犯困呢，今天的运动目标完成了吗？": 17< time && time <= 19 ? msg = "傍晚了！窗外夕阳的景色很美丽呢，最美不过夕阳红~": 19< time && time <= 21 ? msg = "晚上好，今天过得怎么样？": 21< time && time <= 23 && (msg = "已经这么晚了呀，早点休息吧，晚安~"); $.ajax({ type:"get", url:"https://api.gmit.vip/Api/UserInfo/", async:true, success:function(data){ window.info = data; layer.msg("Hi~ 来自"+ data.data.location + '~<br/>通过 '+msgTitle+' 进来的小伙伴！<br/>使用 '+ data.data.os +"&nbsp"+ data.data.browser +' 访问本站！' + '<br/>' + msg); var showFPS = (function(){ var requestAnimationFrame = window.requestAnimationFrame || window.webkitRequestAnimationFrame || window.mozRequestAnimationFrame || window.oRequestAnimationFrame || window.msRequestAnimationFrame || function(callback) { window.setTimeout(callback, 1000/60); }; var e,pe,pid,fps,last,offset,step,appendFps; fps = 0; last = Date.now(); step = function(){ offset = Date.now() - last; fps += 1; if( offset >= 1000 ){ last += offset; appendFps(fps); fps = 0; }; requestAnimationFrame( step ); }; appendFps = function(fps){ var settings = { timeout: 5000, logError: true }; $('#fps').html('<span style="float:left;margin-top:-120px;">'+fps+'FPS</span><br/><span style="float:left;margin-top:-120px;">'+window.info.data.os+'</span><br/><span style="float:left;margin-top:-120px;">'+window.info.data.browser+'</span><br/><span style="float:left;margin-top:-120px;">'+window.info.data.location+'</span><br/><span style="float:left;margin-top:-120px;"></span>'); }; step(); })(); } }); }; }); </script> 
<!-- 访问问候弹窗 -->
<!-- 顶部彩虹条 -->
    <style type="text/css"> #top-img {
        background: url(https://s1.ax1x.com/2020/05/06/YEDWxe.gif);
        height:3px;
        top:0px;
        position: fixed;
        width:100%;
        Z-index:9999;
    } </style>
     
    <div id="top-img"></div>
<!-- 顶部彩虹条 -->
<!-- 右侧导航栏 --> 
<style>
.elevator_item .hd-time-limited {
    display: block;
    position: fixed;
    right: 0;
    bottom: 445px;
    width: 40px;
    height: 80px;
    /*background: url(assets/img/right.png) no-repeat center;*/
}

.elevator_item {
    position: fixed;
    right: 0px;
    bottom: 180px;
    z-index: 11;
}
.elevator_item .feedback {
    width: 40px;
    height: 40px;
    font-size: 5px;
    padding: 6px 5px;
    display: block;
    border-radius: 8px;
    text-align: center;
    margin-top: 7.5px;
    box-shadow: 0 1px 2px rgba(0,0,0,.35);
    cursor: pointer;
}
.graHover {
    position: relative;
    overflow: hidden;
}
</style>
<!-- 右侧导航栏 --> 
<!-- 鼠标右击 -->
        <style type="text/css">
            a {text-decoration: none;}
            div.usercm{background-repeat:no-repeat;background-position:center center;background-size:cover;background-color:#fff;font-size:13px!important;width:130px;-moz-box-shadow:1px 1px 3px rgba
        (0,0,0,.3);box-shadow:0px 0px 15px #333;position:absolute;display:none;z-index:10000;opacity:0.9; border-radius: 8px;}
            div.usercm ul{list-style-type:none;list-style-position:outside;margin:0px;padding:0px;display:block}
            div.usercm ul li{margin:0px;padding:0px;line-height:35px;}
            div.usercm ul li a{color:#666;padding:0 15px;display:block}
            div.usercm ul li a:hover{color:#fff;background:rgba(170,222,18,0.88)}
            div.usercm ul li a i{margin-right:10px}
            a.disabled{color:#c8c8c8!important;cursor:not-allowed}
            a.disabled:hover{background-color:rgba(255,11,11,0)!important}
            div.usercm{background:#fff !important;}
            </style>
        <div class="usercm" style="left: 199px; top: 5px; display: none;">
            <ul>
                <li><a href="http://xnl.asia"><i class="fa fa-home fa-fw"></i><span>首页</span></a></li>
                <li><a href="javascript:void(0);" onclick="getSelect();"><i class="fa fa-copy fa-fw"></i><span>复制</span></a></li>
                <li><a href="javascript:void(0);" onclick="baiduSearch();"><i class="fa fa-search fa-fw"></i><span>搜索</span></a></li>
                <li><a href="javascript:history.go(1);"><i class="fa fa-arrow-right fa-fw"></i><span>前进</span></a></li>
                <li><a href="javascript:history.go(-1);"><i class="fa fa-arrow-left fa-fw"></i><span>后退</span></a></li>
                <li style="border-bottom:1px solid gray"><a href="javascript:window.location.reload();"><i class="fa fa-refresh fa-fw"></i><span>重载网页</span></a></li>
                <li><a href="http://wxnljun.asia/index.php/4.html"><i class="fa fa-meh-o fa-fw"></i><span>祝福板</span></a></li>  
                <li><a href="http://wxnljun.asia/index.php/25.html"><i class="fa fa-pencil-square-o fa-fw"></i><span>点点滴滴</span></a></li>
                   <li><a href="http://music.svipl.cn/"><i class="fa fa-heartbeat fa-fw"></i><span>我的歌单</span></a></li>
            </ul>
        </div>
        <script type="text/javascript">
            (function(a) {
                a.extend({
                    mouseMoveShow: function(b) {
                        var d = 0,
                            c = 0,
                            h = 0,
                            k = 0,
                            e = 0,
                            f = 0;
                        a(window).mousemove(function(g) {
                            d = a(window).width();
                            c = a(window).height();
                            h = g.clientX;
                            k = g.clientY;
                            e = g.pageX;
                            f = g.pageY;
                            h + a(b).width() >= d && (e = e - a(b).width() - 5);
                            k + a(b).height() >= c && (f = f - a(b).height() - 5);
                            a("html").on({
                                contextmenu: function(c) {
                                    3 == c.which && a(b).css({
                                        left: e,
                                        top: f
                                    }).show()
                                },
                                click: function() {
                                    a(b).hide()
                                }
                            })
                        })
                    },
                    disabledContextMenu: function() {
                        window.oncontextmenu = function() {
                            return !1
                        }
                    }
                })
            })(jQuery);

            function getSelect() {
                "" == (window.getSelection ? window.getSelection() : document.selection.createRange().text) ? layer.msg("啊噢...你没还没选择文字呢！") : document.execCommand("Copy")
            }
            function baiduSearch() {
                var a = window.getSelection ? window.getSelection() : document.selection.createRange().text;
                "" == a ? layer.msg("啊噢...你没还没选择文字呢！") : window.open("https://www.baidu.com/s?wd=" + a)
            }
            $(function() {
                for (var a = navigator.userAgent, b = "Android;iPhone;SymbianOS;Windows Phone;iPad;iPod".split(";"), d = !0, c = 0; c < b.length; c++) if (0 < a.indexOf(b[c])) {
                    d = !1;
                    break
                }
                d && ($.mouseMoveShow(".usercm"), $.disabledContextMenu())
            });
            </script>
<!-- 鼠标右击 -->
<style>
/*头像呼吸光环和鼠标悬停旋转放大*/
.avatar{border-radius: 50%; animation: light 4s ease-in-out infinite; transition: 0.5s;}.avatar:hover{transform: scale(1.15) rotate(720deg);}@keyframes light{0%{box-shadow: 0 0 4px #f00;} 25%{box-shadow: 0 0 16px #0f0;} 50%{box-shadow: 0 0 4px #00f;} 75%{box-shadow: 0 0 16px #0f0;} 100%{box-shadow: 0 0 4px #f00;}}

/* logo扫光 */
.navbar-brand{position:relative;overflow:hidden;margin: 0px 0 0 0px;}.navbar-brand:before{content:""; position: absolute; left: -665px; top: -460px; width: 200px; height: 15px; background-color: rgba(255,255,255,.5); -webkit-transform: rotate(-45deg); -moz-transform: rotate(-45deg); -ms-transform: rotate(-45deg); -o-transform: rotate(-45deg); transform: rotate(-45deg); -webkit-animation: searchLights 6s ease-in 0s infinite; -o-animation: searchLights 6s ease-in 0s infinite; animation: searchLights 6s ease-in 0s infinite;}@-moz-keyframes searchLights{50%{left: -100px; top: 0;} 65%{left: 120px; top: 100px;}}@keyframes searchLights{40%{left: -100px; top: 0;} 60%{left: 120px; top: 100px;} 80%{left: -100px; top: 0px;}}
/**彩色滚动条样式*/
::-webkit-scrollbar {
width: 4px;
height: 1px;
}
::-webkit-scrollbar-thumb {
background-color: #12b7f5;
background-image: -webkit-linear-gradient(45deg, rgba(255, 93, 143, 1) 25%, transparent 25%, transparent 50%, rgba(255, 93, 143, 1) 50%, rgba(255, 93, 143, 1) 75%, transparent 75%, transparent);
}
::-webkit-scrollbar-track {
-webkit-box-shadow: inset 0 0 5px rgba(0,0,0,0.2);
background: #f6f6f6;
}
/*lvs*/
    #Snow{
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 99999;
        background: rgba(125,137,95,0.1);
        pointer-events: none;
    }
</style>
<style>/*鼠标样式*/
body {
	cursor: url(https://s1.ax1x.com/2022/05/21/OXYz2d.png),default
}
a:hover {
	cursor: url(https://s1.ax1x.com/2022/05/21/OXt9KI.png),pointer
}
/*鼠标样式*/</style>
<!--侧边标签栏-->
<div class="elevator_item" id="elevator_item" style="display:block;">
<a class="hd-time-limited" href="user/reg.php" rel="nofollow"></a>

<a target="_self" class="feedback graHover" style="background-color: #ff3030;color:#fff;" href="index.php/8.html"><svg class="icon" style="width: 26px;height: 26px;vertical-align: middle;fill: currentColor;overflow: hidden;" viewBox="0 0 1029 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="18960"><path d="M1001.423238 494.592q21.504 20.48 22.528 45.056t-16.384 40.96q-19.456 17.408-45.056 16.384t-40.96-14.336q-5.12-4.096-31.232-28.672t-62.464-58.88-77.824-73.728-78.336-74.24-63.488-60.416-33.792-31.744q-32.768-29.696-64.512-28.672t-62.464 28.672q-10.24 9.216-38.4 35.328t-65.024 60.928-77.824 72.704-75.776 70.656-59.904 55.808-30.208 27.136q-15.36 12.288-40.96 13.312t-44.032-15.36q-20.48-18.432-19.456-44.544t17.408-41.472q6.144-6.144 37.888-35.84t75.776-70.656 94.72-88.064 94.208-88.064 74.752-70.144 36.352-34.304q38.912-37.888 83.968-38.4t76.8 30.208q6.144 5.12 25.6 24.064t47.616 46.08 62.976 60.928 70.656 68.096 70.144 68.096 62.976 60.928 48.128 46.592zM447.439238 346.112q25.6-23.552 61.44-25.088t64.512 25.088q3.072 3.072 18.432 17.408l38.912 35.84q22.528 21.504 50.688 48.128t57.856 53.248q68.608 63.488 153.6 142.336l0 194.56q0 22.528-16.896 39.936t-45.568 18.432l-193.536 0 0-158.72q0-33.792-31.744-33.792l-195.584 0q-17.408 0-24.064 10.24t-6.656 23.552q0 6.144-0.512 31.232t-0.512 53.76l0 73.728-187.392 0q-29.696 0-47.104-13.312t-17.408-37.888l0-203.776q83.968-76.8 152.576-139.264 28.672-26.624 57.344-52.736t52.224-47.616 39.424-36.352 19.968-18.944z" p-id="18961"></path></svg></a>

<a target="_self" class="feedback graHover" id="sign_daily" style="background-color: #ffa500;color:#fff;" rel="nofollow" href="/index.php/4.html"><img src="https://pic1.imgdb.cn/item/6345733016f2c2beb1ce3d12.jpg" width="26px" height="26px"></a>

<!--<a target="_self" class="feedback graHover" style="background-color: #06C17E;color:#fff;" href="/archives/20/"><svg class="icon" style="width: 26px;height: 26px;vertical-align: middle;fill: currentColor;overflow: hidden;" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="12986"><path d="M512 992C246.912 992 32 777.088 32 512 32 246.912 246.912 32 512 32c265.088 0 480 214.912 480 480 0 265.088-214.912 480-480 480z m-59.072-512v236.32a54.144 54.144 0 1 0 108.288 0V480a54.144 54.144 0 1 0-108.288 0z m53.76-226.464c-14.72 0-27.232 4.544-37.568 15.136-11.04 9.856-16.192 22.72-16.192 38.656 0 15.136 5.152 28 16.192 38.624 10.336 10.592 22.848 15.904 37.6 15.904a57.6 57.6 0 0 0 39.04-15.168c10.304-10.592 15.456-23.456 15.456-39.36s-5.12-28.8-15.456-38.656c-10.304-10.56-23.584-15.136-39.04-15.136z" p-id="12987"></path></svg></a>-->

<a target="_self" class="feedback graHover" style="background-color: #3cbdfa;color:#fff;" href="./admin"><svg class="icon" style="width: 26px;height: 26px;vertical-align: middle;fill: currentColor;overflow: hidden;" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="9584"><path d="M506.88 1006.08C371.2 1006.08 240.64 967.68 128 896c-46.08-28.16-69.12-97.28-48.64-143.36 48.64-115.2 153.6-202.24 286.72-240.64-76.8-46.08-128-130.56-128-227.84C238.08 138.24 355.84 17.92 504.32 17.92 647.68 17.92 768 138.24 768 284.16c0 92.16-48.64 174.08-120.32 222.72 135.68 33.28 243.2 120.32 296.96 235.52 20.48 46.08 0 115.2-43.52 145.92-117.76 76.8-253.44 117.76-394.24 117.76" fill="" p-id="9585"></path></svg></a>


<a target="_self" class="feedback graHover" style="background-color: #FF3399;color:#fff;" href="javascript:scroll(0,0)"><svg class="icon" style="width: 26px;height: 26px;vertical-align: middle;fill: currentColor;overflow: hidden;" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="14608"><path d="M856.818373 786.740318c-26.188452 0-52.377928-9.990538-72.359005-29.971615L512 484.308311 239.540631 756.76768c-39.963177 39.963177-104.754832 39.963177-144.716986 0s-39.963177-104.754832 0-144.718009l344.818373-344.818373c19.190061-19.190061 45.218878-29.971615 72.357981-29.971615s53.16792 10.781554 72.359005 29.971615l344.818373 344.818373c39.962154 39.963177 39.962154 104.754832 0 144.718009C909.195278 776.74978 883.005802 786.740318 856.818373 786.740318z" p-id="14609"></path></svg></a></div>
<!--灯笼-->
<!--<div class="deng-box2">-->
<!--  <div class="deng">-->
<!--    <div class="xian"></div>-->
<!--    <div class="deng-a">-->
<!--      <div class="deng-b">-->
<!--        <div class="deng-t">年</div>-->
<!--      </div>-->
<!--    </div>-->
<!--    <div class="shui shui-a">-->
<!--      <div class="shui-c"></div>-->
<!--      <div class="shui-b"></div>-->
<!--    </div>-->
<!--  </div>-->
<!--</div>-->
<!--<div class="deng-box3">-->
<!--  <div class="deng">-->
<!--    <div class="xian"></div>-->
<!--    <div class="deng-a">-->
<!--      <div class="deng-b">-->
<!--        <div class="deng-t">新</div>-->
<!--      </div>-->
<!--    </div>-->
<!--    <div class="shui shui-a">-->
<!--      <div class="shui-c"></div>-->
<!--      <div class="shui-b"></div>-->
<!--    </div>-->
<!--  </div>-->
<!--</div>-->
<!--<div class="deng-box1">-->
<!--  <div class="deng">-->
<!--    <div class="xian"></div>-->
<!--    <div class="deng-a">-->
<!--      <div class="deng-b">-->
<!--        <div class="deng-t">乐</div>-->
<!--      </div>-->
<!--    </div>-->
<!--    <div class="shui shui-a">-->
<!--      <div class="shui-c"></div>-->
<!--      <div class="shui-b"></div>-->
<!--    </div>-->
<!--  </div>-->
<!--</div>-->
<!--<div class="deng-box">-->
<!--  <div class="deng">-->
<!--    <div class="xian"></div>-->
<!--    <div class="deng-a">-->
<!--      <div class="deng-b">-->
<!--        <div class="deng-t">快</div>-->
<!--      </div>-->
<!--    </div>-->
<!--    <div class="shui shui-a">-->
<!--      <div class="shui-c"></div>-->
<!--      <div class="shui-b"></div>-->
<!--    </div>-->
<!--  </div>-->
<!--</div>-->
<!--<style type="text/css">.deng-box {-->
<!--  position: fixed;-->
<!--  top: -40px;-->
<!--  right: -20px;-->
<!--  z-index: 9999;-->
<!--  pointer-events: none-->
<!--}-->

<!--.deng-box1 {-->
<!--  position: fixed;-->
<!--  top: -30px;-->
<!--  right: 10px;-->
<!--  z-index: 9999;-->
<!--  pointer-events: none-->
<!--}-->

<!--.deng-box2 {-->
<!--  position: fixed;-->
<!--  top: -40px;-->
<!--  left: -20px;-->
<!--  z-index: 9999;-->
<!--  pointer-events: none-->
<!--}-->

<!--.deng-box3 {-->
<!--  position: fixed;-->
<!--  top: -30px;-->
<!--  left: 10px;-->
<!--  z-index: 9999;-->
<!--  pointer-events: none-->
<!--}-->

<!--.deng-box1 .deng, .deng-box3 .deng {-->
<!--  position: relative;-->
<!--  width: 120px;-->
<!--  height: 90px;-->
<!--  margin: 50px;-->
<!--  background: #d8000f;-->
<!--  background: rgba(216, 0, 15, .8);-->
<!--  border-radius: 50% 50%;-->
<!--  -webkit-transform-origin: 50% -100px;-->
<!--  -webkit-animation: swing 5s infinite ease-in-out;-->
<!--  box-shadow: -5px 5px 30px 4px #fc903d-->
<!--}-->

<!--.deng {-->
<!--  position: relative;-->
<!--  width: 120px;-->
<!--  height: 90px;-->
<!--  margin: 50px;-->
<!--  background: #d8000f;-->
<!--  background: rgba(216, 0, 15, .8);-->
<!--  border-radius: 50% 50%;-->
<!--  -webkit-transform-origin: 50% -100px;-->
<!--  -webkit-animation: swing 3s infinite ease-in-out;-->
<!--  box-shadow: -5px 5px 50px 4px #fa6c00-->
<!--}-->

<!--.deng-a {-->
<!--  width: 100px;-->
<!--  height: 90px;-->
<!--  background: #d8000f;-->
<!--  background: rgba(216, 0, 15, .1);-->
<!--  margin: 12px 8px 8px 8px;-->
<!--  border-radius: 50% 50%;-->
<!--  border: 2px solid #dc8f03-->
<!--}-->

<!--.deng-b {-->
<!--  width: 45px;-->
<!--  height: 90px;-->
<!--  background: #d8000f;-->
<!--  background: rgba(216, 0, 15, .1);-->
<!--  margin: -4px 8px 8px 26px;-->
<!--  border-radius: 50% 50%;-->
<!--  border: 2px solid #dc8f03-->
<!--}-->

<!--.xian {-->
<!--  position: absolute;-->
<!--  top: -20px;-->
<!--  left: 60px;-->
<!--  width: 2px;-->
<!--  height: 20px;-->
<!--  background: #dc8f03-->
<!--}-->

<!--.shui-a {-->
<!--  position: relative;-->
<!--  width: 5px;-->
<!--  height: 20px;-->
<!--  margin: -5px 0 0 59px;-->
<!--  -webkit-animation: swing 4s infinite ease-in-out;-->
<!--  -webkit-transform-origin: 50% -45px;-->
<!--  background: orange;-->
<!--  border-radius: 0 0 5px 5px-->
<!--}-->

<!--.shui-b {-->
<!--  position: absolute;-->
<!--  top: 14px;-->
<!--  left: -2px;-->
<!--  width: 10px;-->
<!--  height: 10px;-->
<!--  background: #dc8f03;-->
<!--  border-radius: 50%-->
<!--}-->

<!--.shui-c {-->
<!--  position: absolute;-->
<!--  top: 18px;-->
<!--  left: -2px;-->
<!--  width: 10px;-->
<!--  height: 35px;-->
<!--  background: orange;-->
<!--  border-radius: 0 0 0 5px-->
<!--}-->

<!--.deng:before {-->
<!--  position: absolute;-->
<!--  top: -7px;-->
<!--  left: 29px;-->
<!--  height: 12px;-->
<!--  width: 60px;-->
<!--  content: " ";-->
<!--  display: block;-->
<!--  z-index: 999;-->
<!--  border-radius: 5px 5px 0 0;-->
<!--  border: solid 1px #dc8f03;-->
<!--  background: orange;-->
<!--  background: linear-gradient(to right, #dc8f03, orange, #dc8f03, orange, #dc8f03)-->
<!--}-->

<!--.deng:after {-->
<!--  position: absolute;-->
<!--  bottom: -7px;-->
<!--  left: 10px;-->
<!--  height: 12px;-->
<!--  width: 60px;-->
<!--  content: " ";-->
<!--  display: block;-->
<!--  margin-left: 20px;-->
<!--  border-radius: 0 0 5px 5px;-->
<!--  border: solid 1px #dc8f03;-->
<!--  background: orange;-->
<!--  background: linear-gradient(to right, #dc8f03, orange, #dc8f03, orange, #dc8f03)-->
<!--}-->

<!--.deng-t {-->
<!--  font-family: 华文行楷, Arial, Lucida Grande, Tahoma, sans-serif;-->
<!--  font-size: 3.2rem;-->
<!--  color: #dc8f03;-->
<!--  font-weight: 700;-->
<!--  line-height: 85px;-->
<!--  text-align: center-->
<!--}-->

<!--.night .deng-box, .night .deng-box1, .night .deng-t {-->
<!--  background: 0 0 !important-->
<!--}-->

<!--@-moz-keyframes swing {-->
<!--  0% {-->
<!--    -moz-transform: rotate(-10deg)-->
<!--  }-->
<!--  50% {-->
<!--    -moz-transform: rotate(10deg)-->
<!--  }-->
<!--  100% {-->
<!--    -moz-transform: rotate(-10deg)-->
<!--  }-->
<!--}-->

<!--@-webkit-keyframes swing {-->
<!--  0% {-->
<!--    -webkit-transform: rotate(-10deg)-->
<!--  }-->
<!--  50% {-->
<!--    -webkit-transform: rotate(10deg)-->
<!--  }-->
<!--  100% {-->
<!--    -webkit-transform: rotate(-10deg)-->
<!--  }-->
<!--}</style> -->
    <script src="//ku.dzzui.com/js/jquery.min.js"></script> 
<script type="text/javascript" src="//ku.dzzui.com/js/typed.min.js"></script>
 <script src="https://cdn.gmit.vip/blog/js/typed.min.js" type="text/javascript" charset="utf-8"></script>
<script>
   $.ajax({
            type:"get",
            url:"https://api.dzzui.com/api/yiyan?format=json2",
            async:true,
          
     success:function(typed){
            var list = [];
            for(var i = 0 ;i < typed.data.length ; i++){
                list.push(typed.data[i]['text']);
            }
                $("#typed").typed({
                    strings: list,
                    typeSpeed: 20,
                    loop: true,
                    backDelay: 1000,
                });
            }
        });
    </script>
    <div id="j-fish-skip" style=" position: relative;height: 153px;width: auto;"></div>
<script type="text/javascript" src="/usr/themes/Brave/js/fish.min.js"></script></div>
<!--动态-->
</body>

</html>
