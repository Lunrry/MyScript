<?php

/**
 * 主题首页
 * @package custom
 * Author: Veen Zhao
 * CreateTime: 2021/2/6 22:32
 */
$this->need('base/head.php');
$this->need('base/nav.php');
?>
<div class="container">
    <div class=" text-center my-5 py-2">
        <h5 class="lover-card-title">今天是我们相识的</h5>
        <h5 id="meet_runtime" style="color:#3B3838 !important;margin-bottom:10px!important;"></h5>
        <h5 class="lover-card-title">也是我们在一起的</h5>
        <h5 id="site_runtime" style="color:#3B3838 !important;margin-bottom:10px!important;"></h5>
        <h5 class="lover-card-title"><?php $this->options->anniversary() ?></h5>
        <h5 id="<?php $this->options->anniversary() ?>" style="color:#3B3838 !important;"></h5>
    </div>
    <div class="row indexPlate" >
        <div class="col-md-4">
            <a href="<?php $this->options->aboutPageLink() ?>" class="card home-card">
                <div class="card-body" >
                    <div class="row align-items-center">
                        <div class="col-auto">
                            <div class="avatar avatar-md">
                                <img src="<?php $this->options->aboutPageIcon() ?>" alt="..." class="avatar-img rounded-circle">
                            </div>
                        </div>
                        <div class="col">
                            <p class="h5" style="font-family:FangzhengKT;color:#3B3838;">关于</p>
                            <p class="small text-muted mb-1" style="font-family:FangzhengYMZ;">💑我们的经历</p>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="<?php $this->options->timemachinePageLink() ?>" class="card home-card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-auto">
                            <div class="avatar avatar-md">
                                <img src="<?php $this->options->timemachinePageIcon() ?>" alt="..." class="avatar-img rounded-circle">
                            </div>
                        </div>
                        <div class="col">
                            <p class="h5"style="font-family:FangzhengKT;color:#3B3838;">时光机</p>
                            <p class="small text-muted mb-1" style="font-family:FangzhengYMZ;">🕖你言我语</p>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="/index.php/blog/" class="card home-card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-auto">
                            <div class="avatar avatar-md">
                                <img src="<?php $this->options->timePageIcon() ?>" alt="..." class="avatar-img rounded-circle">
                            </div>
                        </div>
                        <div class="col">
                            <p class="h5" style="font-family:FangzhengKT;color:#3B3838;">点点滴滴</p>
                            <p class="small text-muted mb-1" style="font-family:FangzhengYMZ;">💖记录你我生活</p>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="<?php $this->options->albumPageLink() ?>" class="card home-card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-auto">
                            <div class="avatar avatar-md">
                                <img src="<?php $this->options->albumPageIcon() ?>" alt="..." class="avatar-img rounded-circle">
                            </div>
                        </div>
                        <div class="col">
                            <p class="h5" style="font-family:FangzhengKT;color:#3B3838;">相册</p>
                            <p class="small text-muted mb-1" style="font-family:FangzhengYMZ;">🖼️留住你我回忆</p>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="<?php $this->options->loveListPageLink() ?>" class="card home-card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-auto">
                            <div class="avatar avatar-md">
                                <img src="<?php $this->options->loveListPageIcon() ?>" alt="..." class="avatar-img rounded-circle">
                            </div>
                        </div>
                        <div class="col">
                            <p class="h5" style="font-family:FangzhengKT;color:#3B3838;">Love List</p>
                            <p class="small text-muted mb-1" style="font-family:FangzhengYMZ;">📜甜蜜瞬间有你陪伴</p>
                        </div>
                    </div>
                </div>
            </a>
        </div>
        <div class="col-md-4">
            <a href="<?php $this->options->blessingPageLink() ?>" class="card home-card">
                <div class="card-body">
                    <div class="row align-items-center">
                        <div class="col-auto">
                            <div class="avatar avatar-md">
                                <img src="<?php $this->options->blessingPageIcon() ?>" alt="..." class="avatar-img rounded-circle">
                            </div>
                        </div>
                        <div class="col">
                            <p class="h5"style="font-family:FangzhengKT;color:#3B3838;">祝福板</p>
                            <p class="small text-muted mb-1" style="font-family:FangzhengYMZ;">💌写下对我们的祝福</p>
                        </div>
                    </div>
                </div>
            </a>
        </div>
    </div>
</div>


    <script type="text/javascript">
        (function () {
            window.TypechoComment = {
                dom: function (id) {
                    return document.getElementById(id);
                },

                create: function (tag, attr) {
                    var el = document.createElement(tag);

                    for (var key in attr) {
                        el.setAttribute(key, attr[key]);
                    }

                    return el;
                },

                reply: function (cid, coid) {
                    var comment = this.dom(cid), parent = comment.parentNode,
                        response = this.dom('respond-page-3'), input = this.dom('comment-parent'),
                        form = 'form' == response.tagName ? response : response.getElementsByTagName('form')[0],
                        textarea = response.getElementsByTagName('textarea')[0];

                    if (null == input) {
                        input = this.create('input', {
                            'type': 'hidden',
                            'name': 'parent',
                            'id': 'comment-parent'
                        });

                        form.appendChild(input);
                    }

                    input.setAttribute('value', coid);

                    if (null == this.dom('comment-form-place-holder')) {
                        var holder = this.create('div', {
                            'id': 'comment-form-place-holder'
                        });

                        response.parentNode.insertBefore(holder, response);
                    }

                    comment.appendChild(response);
                    this.dom('cancel-comment-reply-link').style.display = '';

                    if (null != textarea && 'text' == textarea.name) {
                        textarea.focus();
                    }

                    return false;
                },

                cancelReply: function () {
                    var response = this.dom('respond-page-3'),
                        holder = this.dom('comment-form-place-holder'), input = this.dom('comment-parent');

                    if (null != input) {
                        input.parentNode.removeChild(input);
                    }

                    if (null == holder) {
                        return true;
                    }

                    this.dom('cancel-comment-reply-link').style.display = 'none';
                    holder.parentNode.insertBefore(response, holder);
                    return false;
                }
            };
        })();
    </script>



    

<style>
    .tablebox {
        height: 360px;
        overflow: hidden;
        position: relative;
        width: 100%;
        margin: 0px auto;
        
    }

    .tbl-header {
        width: 100%;
        position: absolute;
        top: 0;
        left: 0;
        z-index: 999;
    }

    .tbl-body {
        width: 100%;
        position: absolute;
        top: 0;
        left: 0;
    }

    .tablebox table {
        width: 100%;
    }

        .tablebox table th,
        .tablebox table td {
            font-size: 15px;
            color: rgb(62, 62, 62);
            font-family: PingFangSC-light;
            line-height: 45px;
            text-align: center;
        }

        .tablebox table tr th {
            
            cursor: pointer;
        }

        .tablebox table tr td {
            background-color: transparent;
        }

    .tbl-body tr:nth-child(even) td, .tbl-body1 tr:nth-child(even) td {
        
    }

    .tablebox table tr td span,
    .tablebox table tr td span {
        font-size: 24px;
    }
</style>

<section id="Pjax">
    <div class="container">

        <div class="layui-col-md6" style="margin: 10px 0 26px 0; background-position: 50% 50%; border-color: pink; border-style: solid; border-width: 2px; border-radius: 10px; background-repeat: no-repeat; background-size: cover; background-attachment: scroll; background-image: url(&#39;http://img.91jingyun.com:8081/2022/5/0519/20220519140059_369146ae67e34dda45c493091365d468f5fb.png&#39;); opacity: 0.9; ">
            <div class="layui-card">
                <div class="layui-card-body" style="">
                    <div class="tablebox" style="border-radius:10px;">
                        <div class="tbl-body" style="top: -97px;">
                            <table border="0" cellspacing="0" cellpadding="0">
                                <thead>
                                    <tr>
                                        <th></th>
                                    </tr>
                                </thead>
                                <tbody><tr><td>茫茫人海中，你是晚来风</td></tr><tr><td>俗话说的好，我爱你</td></tr><tr><td>爱就一个字，我只说一次</td></tr><tr><td>深情不及久伴，厚爱无需多言</td></tr><tr><td>夏天总想你，夏天不听话</td></tr><tr><td>我的每一支笔都知道你的名字</td></tr><tr><td>总有些惊奇的际遇，比方说当我遇见你</td></tr><tr><td>我查了余生的黄历，除了爱你诸事不宜</td></tr><tr><td>人间纵有百媚千红，唯有你是情之所钟</td></tr><tr><td>我一生擅长的事不多，除了爱你</td></tr><tr><td>把对你的喜欢酿成酒，十里外的猫都醉了</td></tr><tr><td>自从遇见你，人生苦短，甜长</td></tr><tr><td>你是年少的欢喜，这句话反过来还是你</td></tr><tr><td>静下来想你，觉得一切都美好得不可思议</td></tr><tr><td>不管我本人多么平庸，我总觉得对你的爱很美</td></tr><tr><td>一想到你,我这张丑脸就泛起微笑</td></tr><tr><td>有时候你就像安眠药, 见你一眼才能安稳入睡</td></tr><tr><td>爱你就像爱生命</td></tr><tr><td>我会爱你很久很久</td></tr><tr><td>陪你把岁月熬成清酒 陪你把孤夜熬成温柔</td></tr><tr><td>只想拥你入怀</td></tr><tr><td>日月星辰之外 你是第四种难得</td></tr><tr><td>我会在每个有意义的时刻 远隔山海与你共存</td></tr><tr><td>想试试在你迎面跑来一把抱住你的感觉</td></tr><tr><td>如果不曾遇见 岂知生命如何</td></tr><tr><td>r=a(1-sinθ)</td></tr><tr><td>今晚月色很美呢</td></tr><tr><td>你不用多好，我喜欢就好</td></tr><tr><td>愿有岁月可回首 且以深情共白头</td></tr><tr><td>茫茫人海中，你是晚来风</td></tr><tr><td>俗话说的好，我爱你</td></tr><tr><td>爱就一个字，我只说一次</td></tr><tr><td>深情不及久伴，厚爱无需多言</td></tr><tr><td>夏天总想你，夏天不听话</td></tr><tr><td>我的每一支笔都知道你的名字</td></tr><tr><td>总有些惊奇的际遇，比方说当我遇见你</td></tr><tr><td>我查了余生的黄历，除了爱你诸事不宜</td></tr><tr><td>人间纵有百媚千红，唯有你是情之所钟</td></tr><tr><td>我一生擅长的事不多，除了爱你</td></tr><tr><td>把对你的喜欢酿成酒，十里外的猫都醉了</td></tr><tr><td>自从遇见你，人生苦短，甜长</td></tr><tr><td>你是年少的欢喜，这句话反过来还是你</td></tr><tr><td>静下来想你，觉得一切都美好得不可思议</td></tr><tr><td>不管我本人多么平庸，我总觉得对你的爱很美</td></tr><tr><td>一想到你,我这张丑脸就泛起微笑</td></tr><tr><td>有时候你就像安眠药, 见你一眼才能安稳入睡</td></tr><tr><td>爱你就像爱生命</td></tr><tr><td>我会爱你很久很久</td></tr><tr><td>陪你把岁月熬成清酒 陪你把孤夜熬成温柔</td></tr><tr><td>只想拥你入怀</td></tr><tr><td>日月星辰之外 你是第四种难得</td></tr><tr><td>我会在每个有意义的时刻 远隔山海与你共存</td></tr><tr><td>想试试在你迎面跑来一把抱住你的感觉</td></tr><tr><td>如果不曾遇见 岂知生命如何</td></tr><tr><td>r=a(1-sinθ)</td></tr><tr><td>今晚月色很美呢</td></tr><tr><td>你不用多好，我喜欢就好</td></tr><tr><td>愿有岁月可回首 且以深情共白头</td></tr></tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <video id="qipaVideo" controls="controls" name="media" style="border-radius: 10px; width: 100%; height: auto; background-color: rgb(0, 0, 0); padding: 0px 5px;">
            <source id="sourbox" src="http://47.97.73.68:8021/UploadFile/file/lovefilm.mp4?t=1" type="video/mp4" muted="muted" preload="auto" controls="controls">
        </video>
    </div>
</section>



    <!--页尾-->
    
    <!-- 页脚 -->

   
    <script>
        $(document).pjax('a', '#Pjax', {
            fragment: '#Pjax',
            timeout: 6000
        });
        $(document).on('pjax:send', function () {
            NProgress.start();
        });
        $(document).on('pjax:complete', function () {
            NProgress.done();
        });
    </script>

    
    <script type="text/javascript">
        //滚动框
        var MyMarhq = '';
        clearInterval(MyMarhq);
        $('.tbl-body tbody').empty();
        $('.tbl-header tbody').empty();
        var str = '';

        var Items = [{"category_id":3,"pid":0,"d_value":"茫茫人海中，你是晚来风","sort":0,"id":9,"create_time":"2022/05/19 13:47:54","modify_time":"2022/05/19 13:47:54"},{"category_id":3,"pid":0,"d_value":"俗话说的好，我爱你","sort":0,"id":10,"create_time":"2022/05/19 13:47:56","modify_time":"2022/05/19 13:47:56"},{"category_id":3,"pid":0,"d_value":"爱就一个字，我只说一次","sort":0,"id":11,"create_time":"2022/05/19 13:47:57","modify_time":"2022/05/19 13:47:57"},{"category_id":3,"pid":0,"d_value":"深情不及久伴，厚爱无需多言","sort":0,"id":12,"create_time":"2022/05/19 13:47:57","modify_time":"2022/05/19 13:47:57"},{"category_id":3,"pid":0,"d_value":"夏天总想你，夏天不听话","sort":0,"id":13,"create_time":"2022/05/19 13:47:57","modify_time":"2022/05/19 13:47:57"},{"category_id":3,"pid":0,"d_value":"我的每一支笔都知道你的名字","sort":0,"id":14,"create_time":"2022/05/19 13:47:57","modify_time":"2022/05/19 13:47:57"},{"category_id":3,"pid":0,"d_value":"总有些惊奇的际遇，比方说当我遇见你","sort":0,"id":15,"create_time":"2022/05/19 13:47:58","modify_time":"2022/05/19 13:47:58"},{"category_id":3,"pid":0,"d_value":"我查了余生的黄历，除了爱你诸事不宜","sort":0,"id":16,"create_time":"2022/05/19 13:47:58","modify_time":"2022/05/19 13:47:58"},{"category_id":3,"pid":0,"d_value":"人间纵有百媚千红，唯有你是情之所钟","sort":0,"id":17,"create_time":"2022/05/19 13:47:58","modify_time":"2022/05/19 13:47:58"},{"category_id":3,"pid":0,"d_value":"我一生擅长的事不多，除了爱你","sort":0,"id":18,"create_time":"2022/05/19 13:47:58","modify_time":"2022/05/19 13:47:58"},{"category_id":3,"pid":0,"d_value":"把对你的喜欢酿成酒，十里外的猫都醉了","sort":0,"id":19,"create_time":"2022/05/19 13:47:59","modify_time":"2022/05/19 13:47:59"},{"category_id":3,"pid":0,"d_value":"自从遇见你，人生苦短，甜长","sort":0,"id":20,"create_time":"2022/05/19 13:47:59","modify_time":"2022/05/19 13:47:59"},{"category_id":3,"pid":0,"d_value":"你是年少的欢喜，这句话反过来还是你","sort":0,"id":21,"create_time":"2022/05/19 13:47:59","modify_time":"2022/05/19 13:47:59"},{"category_id":3,"pid":0,"d_value":"静下来想你，觉得一切都美好得不可思议","sort":0,"id":23,"create_time":"2022/05/19 13:48:00","modify_time":"2022/05/19 13:48:00"},{"category_id":3,"pid":0,"d_value":"不管我本人多么平庸，我总觉得对你的爱很美","sort":0,"id":24,"create_time":"2022/05/19 13:48:00","modify_time":"2022/05/19 13:48:00"},{"category_id":3,"pid":0,"d_value":"一想到你,我这张丑脸就泛起微笑","sort":0,"id":25,"create_time":"2022/05/19 13:48:06","modify_time":"2022/05/19 13:48:06"},{"category_id":3,"pid":0,"d_value":"有时候你就像安眠药, 见你一眼才能安稳入睡","sort":0,"id":26,"create_time":"2022/05/19 13:48:07","modify_time":"2022/05/19 13:48:07"},{"category_id":3,"pid":0,"d_value":"爱你就像爱生命","sort":0,"id":27,"create_time":"2022/05/19 13:48:07","modify_time":"2022/05/19 13:48:07"},{"category_id":3,"pid":0,"d_value":"我会爱你很久很久","sort":0,"id":28,"create_time":"2022/05/19 14:07:13","modify_time":"2022/05/19 14:07:13"},{"category_id":3,"pid":0,"d_value":"陪你把岁月熬成清酒 陪你把孤夜熬成温柔","sort":0,"id":29,"create_time":"2022/05/19 14:07:13","modify_time":"2022/05/19 14:07:13"},{"category_id":3,"pid":0,"d_value":"只想拥你入怀","sort":0,"id":30,"create_time":"2022/05/19 14:07:13","modify_time":"2022/05/19 14:07:13"},{"category_id":3,"pid":0,"d_value":"日月星辰之外 你是第四种难得","sort":0,"id":31,"create_time":"2022/05/19 14:07:14","modify_time":"2022/05/19 14:07:14"},{"category_id":3,"pid":0,"d_value":"我会在每个有意义的时刻 远隔山海与你共存","sort":0,"id":32,"create_time":"2022/05/19 14:07:14","modify_time":"2022/05/19 14:07:14"},{"category_id":3,"pid":0,"d_value":"想试试在你迎面跑来一把抱住你的感觉","sort":0,"id":33,"create_time":"2022/05/19 14:07:58","modify_time":"2022/05/19 14:07:58"},{"category_id":3,"pid":0,"d_value":"如果不曾遇见 岂知生命如何","sort":0,"id":34,"create_time":"2022/05/19 14:07:59","modify_time":"2022/05/19 14:07:59"},{"category_id":3,"pid":0,"d_value":"r=a(1-sinθ)","sort":0,"id":35,"create_time":"2022/05/19 14:07:59","modify_time":"2022/05/19 14:07:59"},{"category_id":3,"pid":0,"d_value":"今晚月色很美呢","sort":0,"id":36,"create_time":"2022/05/19 14:07:59","modify_time":"2022/05/19 14:07:59"},{"category_id":3,"pid":0,"d_value":"你不用多好，我喜欢就好","sort":0,"id":37,"create_time":"2022/05/19 14:08:00","modify_time":"2022/05/19 14:08:00"},{"category_id":3,"pid":0,"d_value":"愿有岁月可回首 且以深情共白头","sort":0,"id":38,"create_time":"2022/05/19 14:08:51","modify_time":"2022/05/19 14:08:51"}]
        console.log(Items)

        $.each(Items, function (i, item) {
            str = '<tr>' +
                '<td>' + item.d_value + '</td>' +
            '</tr>'
            $('.tbl-body tbody').append(str);
            $('.tbl-header tbody').append(str);
        });

        if (Items.length > 5) {
            $('.tbl-body tbody').html($('.tbl-body tbody').html() + $('.tbl-body tbody').html());
            $('.tbl-body').css('top', '0');
            var tblTop = 0;
            var speedhq = 60; // 数值越大越慢
            var outerHeight = $('.tbl-body tbody').find("tr").outerHeight();
            function Marqueehq() {
                if (tblTop <= -outerHeight * Items.length) {
                    tblTop = 0;
                } else {
                    tblTop -= 1;
            }
            $('.tbl-body').css('top', tblTop + 'px');
        }

        MyMarhq = setInterval(Marqueehq, speedhq);

        // 鼠标移上去停止滚动事件
        $(".tbl-header tbody").hover(function () {
            clearInterval(MyMarhq);
        }, function () {
            clearInterval(MyMarhq);
            MyMarhq = setInterval(Marqueehq, speedhq);
        })
    }
    </script>

    <script type="text/javascript">
        window.showSiteRuntime = function () {
            site_runtime = $("#site_runtime");
            if (!site_runtime) {
                return;
            }
            window.setTimeout("showSiteRuntime()", 1000);
            start = new Date("2022-11-01");
            now = new Date();
            T = (now.getTime() - start.getTime());
            i = 24 * 60 * 60 * 1000;
            d = T / i;
            D = Math.floor(d);
            h = (d - D) * 24;
            H = Math.floor(h);
            m = (h - H) * 60;
            M = Math.floor(m);
            s = (m - M) * 60
            S = Math.floor(s);
            site_runtime.html("第 <span class=\"bigfontNum\">" + D + "</span> 天 <span class=\"bigfontNum\">" + H + "</span> 小时 <span class=\"bigfontNum\">" + M + "</span> 分钟 <span class=\"bigfontNum\">" + S + "</span> 秒");
        };
        showSiteRuntime();
    </script>

<script src="/usr/themes/Brave/botui/vue.min.js"></script>
<script src="/usr/themes/Brave/botui/botui.min.js"></script>
<script src="/usr/themes/Brave/botui/botui.js"></script>
<?php $this->need('base/footer.php'); ?>