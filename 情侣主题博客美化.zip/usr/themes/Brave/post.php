<?php
if (!defined('__TYPECHO_ROOT_DIR__')) exit;
$this->need('base/head.php');
$this->need('base/nav.php');
?>
<div class="list-content mx-auto mt-5" >
    <div id="article" class="list-top" >
        <h5 class="list-text" style="font-size:22px;color:#333;font-weight:700;">💕<?php $this->title() ?>💕</h5>
        <article>
            <?php $this->content(); ?>
                                    <div style="padding: 10px;background: rgba(220, 220, 220, 0.22);font-size: 13px;border-left: 3px solid;text-align: left;">
<span>本文作者：<a href="<?php $this->author->permalink(); ?>" rel="author"> <?php $this->author(); ?></a></span>

<span>文章标题：<a href="<?php $this->permalink() ?>"><?php $this->title() ?></a><br>
<span>本文地址：<a href="<?php $this->permalink() ?>"><?php $this->permalink() ?></a><br>
<span>版权说明：若无注明，本文皆<a href="<?php $this->options->rootUrl(); ?>" target="_blank" data-original-title="<?php $this->options->title() ?>"><?php $this->options->title() ?></a>原创，转载请保留文章出处。</span>
        </article>
    </div>
</div>
<?php $this->need('base/footer.php'); ?>